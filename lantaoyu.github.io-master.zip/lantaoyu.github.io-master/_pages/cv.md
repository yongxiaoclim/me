---
<!-- layout: archive -->
title: "Lantao Yu (于澜涛)"
permalink: /cv/
author_profile: true
redirect_from:
  - /resume
---

{% include base_path %}

[Click to View My Up-to-date Curriculum Vitae [PDF]](http://lantaoyu.github.io/files/lantaoyu_cv.pdf)

<!-- <embed src="http://lantaoyu.com/files/lantaoyu_cv.pdf" width="650" height="1800" type='application/pdf'> -->
