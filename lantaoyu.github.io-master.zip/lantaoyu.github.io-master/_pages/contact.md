---
layout: archive
title: "Contact"
permalink: /contact/
author_profile: true
---
Computer Science Department, Stanford University<br>
Gates 158, 353 Serra Mall, Stanford, CA 94305<br>
Email: lantaoyu [at] cs.stanford.edu

