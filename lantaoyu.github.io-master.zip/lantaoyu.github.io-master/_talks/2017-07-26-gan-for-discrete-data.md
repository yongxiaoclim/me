---
title: "Generative Adversarial Networks for Discrete Data"
collection: talks
type: "Talk"
permalink: /talks/2017-07-26-gan-for-discrete-data
venue: "Paperweekly"
date: 2017-07-26
location: "Shanghai, China"
---

Online talk on how to apply adversarial training for generating discrete data.<br>
[[Slide]](http://lantaoyu.github.io/files/2017-07-26-gan-for-discrete-data.pdf)