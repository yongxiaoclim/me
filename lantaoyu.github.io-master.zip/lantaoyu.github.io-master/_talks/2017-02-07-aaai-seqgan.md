---
title: "Sequence Generative Adversarial Nets with Policy Gradient"
collection: talks
type: "Talk"
permalink: /talks/2017-02-07-aaai-seqgan
venue: "31st AAAI conference on Artificial Intelligence"
date: 2017-02-07
location: "San Francisco, California"
---

Oral Presentation of the research paper [Sequence Generative Adversarial Nets with Policy Gradient](https://arxiv.org/pdf/1609.05473.pdf) on the 31st AAAI Conference on Artificial Intellgence.<br>
[[Slide]](http://lantaoyu.github.io/files/2017-02-07-aaai-seqgan.pdf)