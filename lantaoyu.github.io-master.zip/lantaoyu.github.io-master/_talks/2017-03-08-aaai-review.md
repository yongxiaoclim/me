---
title: "AAAI 2017 Review"
collection: talks
type: "Talk"
permalink: /talks/2017-03-08-aaai-review
venue: "Apex Lab, Shanghai Jiao Tong University"
date: 2017-03-08
location: "Shanghai, China"
---

Review of The Thirt-First AAAI Conference on Artificial Intelligence.<br>
[[Slide]](http://lantaoyu.github.io/files/2017-03-08-aaai-review.pdf)