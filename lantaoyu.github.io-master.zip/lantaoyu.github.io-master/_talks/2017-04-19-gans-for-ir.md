---
title: "Generative Adversarial Networks for Information Retrieval"
collection: talks
type: "Talk"
permalink: /talks/2017-04-19-gans-for-ir
venue: "Apex Lab, Shanghai Jiao Tong University"
date: 2017-04-19
location: "Shanghai, China"
---

Introduction of two research papers on applying adversarial training for information retrieval.<br>
[[Slide]](http://lantaoyu.github.io/files/2017-04-19-gans-for-ir.pdf)